import kotlinx.coroutines.experimental.CommonPool
import kotlinx.coroutines.experimental.delay
import kotlinx.coroutines.experimental.launch
import java.util.concurrent.TimeUnit

val <T> List<T>.lastIndex: Int get() = size - 1

fun String.notEmpty(): String {
    return this
}

operator fun Int.plus(str: Any): String {
    return this.toString() + str
}


fun isOdd(x: Int) = x % 2 != 0
fun length(s: String) = s.length
fun <A, B, C> compose(f: (B) -> C, g: (A) -> B): (A) -> C {
    return { x -> f(g(x)) }
}


fun coroutineTest() {
    launch(CommonPool) {
        delay(3000L, TimeUnit.MILLISECONDS)
        println("123456")
    }
    println("654321")
    Thread.sleep(1000L)
}


fun main(args: Array<String>) {
    val oddLength = compose(::isOdd, ::length)
    val strings = listOf("a", "aa", "aaaa", "aaaaaaa")
    val str = "aaa"
    println(oddLength(str))
    println(strings.filter(oddLength))

}



