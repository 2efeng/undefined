package com.hzf.client.service

import com.hzf.client.manage.WebServiceEntity
import net.sf.json.JSONObject
import org.apache.http.HttpEntity
import org.apache.http.HttpResponse
import org.apache.http.client.config.RequestConfig
import org.apache.http.client.methods.HttpGet
import org.apache.http.client.methods.HttpPost
import org.apache.http.entity.StringEntity
import org.apache.http.impl.client.HttpClients
import org.apache.http.util.EntityUtils

class WebServiceClientImpl : WebServiceClient {

    private val httpClient = HttpClients.createDefault()
    private val requestConfig = RequestConfig.custom()
            .setConnectTimeout(3000) //连接超时 3s
            .build()

    override fun doGet(url: String): String? {
        val httpGet = HttpGet(url)
        httpGet.config = requestConfig
        val response: HttpResponse? = httpClient.execute(httpGet)
        return getResult(response = response)
    }

    override fun doPost(url: String, entity: WebServiceEntity): String? {
        val jsonObject: JSONObject = JSONObject.fromObject(entity.getParam())
        val httpPost = HttpPost(url)
        httpPost.config = requestConfig
        val stringEntity = StringEntity(jsonObject.toString(), "UTF-8")
        stringEntity.setContentType("application/json; charset=UTF-8")
        stringEntity.setContentEncoding("gzip")
        httpPost.entity = stringEntity
        val response: HttpResponse? = httpClient.execute(httpPost)
        return getResult(response)
    }

    private fun getResult(response: HttpResponse?): String? {
        if (response != null) {
            val resEntity: HttpEntity? = response.entity
            if (resEntity != null) {
                val result:String = EntityUtils.toString(resEntity, "UTF-8")
                EntityUtils.consume(resEntity)
                return result
            }
        }
        return null
    }

}