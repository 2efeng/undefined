package com.hzf.client.instance

import com.hzf.client.service.WebServiceClient
import org.apache.log4j.Logger

internal class HDFSThreadService(url: String, private val client: WebServiceClient) : Thread() {

    companion object {
        private val logger = Logger.getLogger(HDFSThreadService::class.java)
    }


    override fun run() {

    }

}