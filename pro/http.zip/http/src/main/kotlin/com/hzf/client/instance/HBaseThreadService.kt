package com.hzf.client.instance

import com.hzf.client.service.WebServiceClient
import org.apache.log4j.Logger

internal class HBaseThreadService(url: String, client: WebServiceClient) : Thread() {

    companion object {
        private val logger = Logger.getLogger(HBaseThreadService::class.java)
    }

    private val newUrl: String = url + "savehbaselocal"
    private var isFlag = true

    fun setFlag() {
        this.isFlag = false
    }

    override fun run() {
        while (isFlag) {
            try {
                save()
            } catch (e: Exception) {
                logger.error("HBaseThreadService run ")
            }

        }
    }

    @Throws(Exception::class)
    private fun save() {


    }


}
