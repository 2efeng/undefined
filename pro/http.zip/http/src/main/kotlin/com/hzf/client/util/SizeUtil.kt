package com.hzf.client.util

import java.io.FileInputStream
import java.nio.channels.FileChannel

internal object SizeUtil {

    //按操作系统默认编码来编码
    fun getSize(content: String): String {
        return getResult(content.toByteArray().size.toLong())
    }

    //按encode编码来编码
    @Throws(Exception::class)
    fun getSize(content: String, encode: String): String {
        return getResult(content.toByteArray(charset(encode)).size.toLong())
    }

    //根据文件流
    @Throws(Exception::class)
    fun getSize(fileIn: FileInputStream): String {
        val fc: FileChannel = fileIn.channel
        return getResult(fc.size())
    }

    private fun getResult(size: Long): String {
        return when {
            size < 1024 -> size.toString() + "B"
            size < 1024 * 1024 -> (size / 1024).toString() + "KB"
            size < 1024 * 1024 * 1024 -> (size / 1024 / 1024).toString() + "MB"
            else -> (size / 1024 / 1024 / 1024).toString() + "GB"
        }
    }

}