package com.hzf.client.instance

import com.hzf.client.constant.*
import com.hzf.client.manage.WebServiceEntity
import com.hzf.client.service.*
import com.hzf.client.util.*
import net.sf.json.JSONArray
import net.sf.json.JSONObject
import org.apache.log4j.Logger
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.*

class HBaseClient private constructor() {

    companion object {

        private val logger = Logger.getLogger(HBaseClient::class.java)
        @Volatile private var url: String? = null
        @Volatile private var stype: String? = null
        @Volatile private var client: WebServiceClient? = null
        @Volatile private var instance: HBaseClient? = null
        @Volatile private var newUrl: String? = null
        @Volatile private var HBaseThread: HBaseThreadService? = null
        @Volatile private var HDFSThread: HDFSThreadService? = null

        @Synchronized
        fun getInstance(url: String, stype: String): HBaseClient {
            this.url = url
            this.stype = stype
            if (instance == null) {
                instance = HBaseClient()
            }
            if (newUrl == null) {
                getNewUrl()
            }
            return instance as HBaseClient
        }

        @Throws(Exception::class)
        @Synchronized
        private fun getNewUrl() {
            try {
                val urlStr: String = this.url + "?stype=" + this.stype
                val result: String? = getClient(client).doGet(urlStr)
                if (result != null) {
                    val json: JSONObject = JsonUtil.str2json(result)
                    newUrl = json.getJSONArray(ResultKey.Data).getString(0)
                } else {
                    logger.error("can not get url!")
                }
            } catch (e: Exception) {
                logger.error(e)
                throw e
            }
        }

        @Synchronized
        private fun getClient(client: WebServiceClient?): WebServiceClient {
            if (client == null) {
                return WebServiceClientImpl()
            }
            return client
        }

    }


    /**
     * 获取保存文件时的Path路径下的所有FullFileName列表
     *
     * @param spiderInstanceID SpiderInstanceID
     * @param path             路径
     */
    @Synchronized
    @Throws(Exception::class)
    fun loadFileNamesByPath(spiderInstanceID: String, path: String): List<String> {
        val url: String = newUrl + "getfilesbypath?ssid=" + spiderInstanceID + "&path=" + path
        val fileNames = ArrayList<String>()
        try {
            val start: Long = System.currentTimeMillis()
            val result: String? = getClient(client).doGet(url)
            val end: Long = System.currentTimeMillis()
            if (result != null) {
                val json: JSONObject = JsonUtil.str2json(result)
                if (json.getBoolean(ResultKey.Result)) {
                    val array: JSONArray = json.getJSONArray(ResultKey.Data)
                    array.mapTo(fileNames) { it.toString() }
                    val filesCount: Int = fileNames.size
                    if (filesCount <= 0) {
                        logger.info("$spiderInstanceID/$path not found files!   time:${end - start}ms")
                    } else {
                        logger.info("$spiderInstanceID/$path there are $filesCount files   time:${end - start}ms")
                    }
                } else {
                    fileNames.clear()
                    val msg: String = json.getString(ResultKey.ExceptionMsg)
                    throw  Exception(msg)
                }
            }
        } catch (e: Exception) {
            logger.error(e)
            throw e
        }
        return fileNames
    }


    /**
     * 获取带前缀withFileNamePrefix的所有FullFileName列表
     *
     * @param spiderInstanceID   SpiderInstanceID
     * @param prefix             前缀
     */
    @Synchronized
    @Throws(Exception::class)
    fun loadFileNamesByPrefix(spiderInstanceID: String, prefix: String): List<String> {
        val fileNames = ArrayList<String>()
        val url: String = newUrl + "getfilesbypredix?ssid=" + spiderInstanceID + "&prefix=" + prefix
        try {
            val startTime: Long = System.currentTimeMillis()
            val result: String? = getClient(client).doGet(url)
            val endTime: Long = System.currentTimeMillis()
            if (result != null) {
                val json: JSONObject = JsonUtil.str2json(result)
                if (json.getBoolean(ResultKey.Result)) {
                    val array: JSONArray = json.getJSONArray(ResultKey.Data)
                    array.mapTo(fileNames) { it.toString() }
                    val filesCount: Int = fileNames.size
                    if (filesCount <= 0) {
                        logger.info("SpiderInstanceID:$spiderInstanceID & FileNamePrefix:$prefix not found files!   time:${endTime - startTime}ms")
                    } else {
                        logger.info("SpiderInstanceID:$spiderInstanceID & FileNamePrefix:$prefix there are $filesCount files    time:${endTime - startTime}ms")

                    }
                } else {
                    fileNames.clear()
                    val msg: String = json.getString(ResultKey.ExceptionMsg)
                    throw Exception(msg)
                }
            }
        } catch (e: Exception) {
            logger.error(e)
            throw e
        }
        return fileNames
    }

    /**
     * 获取文件内容
     *
     * @param spiderInstanceID SpiderInstanceID
     * @param fileName         文件名 or 路径/文件名
     */
    @Synchronized
    @Throws(Exception::class)
    fun getFileContent(spiderInstanceID: String, fileName: String): String {
        val url: String = newUrl + "getcontent?ssid=" + spiderInstanceID + "&filename=" + fileName
        var content = ""
        try {
            val startTime: Long = System.currentTimeMillis()
            val result: String? = getClient(client).doGet(url)
            val endTime: Long = System.currentTimeMillis()
            if (result != null) {
                val json: JSONObject = JsonUtil.str2json(result)
                if (json.getBoolean(ResultKey.Result)) {
                    content = json.getJSONArray(ResultKey.Data).getString(0)
                    val fileSize: String = SizeUtil.getSize(result, "UTF-8")
                    logger.info("get file content of $spiderInstanceID/$fileName success!   fileSize:$fileSize / time:${endTime - startTime}ms")
                } else {
                    val msg: String = json.getString(ResultKey.ExceptionMsg)
                    throw Exception(msg)
                }
            }
        } catch (e: Exception) {
            logger.error(e)
            throw e
        }
        return content
    }

    /**
     * 下载HDFS文件到本地
     *
     * @param spiderInstanceID SpiderInstanceID
     * @param fileName         HDFS路径/文件名(需要后缀)
     * @param localPath        本地路径/文件名(需要后缀)
     */
    @Synchronized
    @Throws(Exception::class)
    fun downloadFile(spiderInstanceID: String, fileName: String, localPath: String) {
        val url: String = newUrl + "getfilestream?ssid=" + spiderInstanceID + "&filename=" + fileName
        var out: FileOutputStream? = null
        try {
            val startTime: Long = System.currentTimeMillis()
            val result: String? = getClient(client).doGet(url)
            val endTime: Long = System.currentTimeMillis()
            if (result == null)
                return
            val json: JSONObject = JsonUtil.str2json(result)
            if (json.getBoolean(ResultKey.Result)) {
                val base64: String? = json.getJSONArray(ResultKey.Data).getString(0)
                if (base64 == null || base64 == "")
                    return
                val data: ByteArray = Base64Util.decodeBase64ToFile(base64)
                out = FileOutputStream(localPath)
                out.write(data)
                logger.info("download $spiderInstanceID/$fileName to $localPath    time:${endTime - startTime}ms")
            } else {
                val msg: String = json.getString(ResultKey.ExceptionMsg)
                throw Exception(msg)
            }
        } catch (e: Exception) {
            logger.error(e)
            throw e
        } finally {
            out?.close()
        }
    }
    //===========================  以下是3个保存数据的异步方法  ===========================//
    // 1.保存hbase数据
    // 2.保存hdfs数据
    // 3.保存文件流到hdfs
    //==================================================================================//



    //==================================================================================//


    //===========================  以下是3个保存数据的同步方法  ===========================//
    // 1.保存hbase数据
    // 2.保存hdfs数据
    // 3.保存文件流到hdfs
    //==================================================================================//
    /**
     * 保存hbase数据
     *
     * @param spiderInstanceId SpiderInstanceID
     * @param date             日期
     * @param dataContent      数据内容
     * @param dataType         数据格式
     */
    @Throws(Exception::class)
    @Synchronized
    fun saveFileSyn(spiderInstanceId: String, date: Date, dataContent: String, dataType: DataType) {
        try {
            val entity = WebServiceEntity(Type.HBase, spiderInstanceId, date, dataContent, dataType)
            val url: String = newUrl + "savehbaselocal"
            val contentSize: String = SizeUtil.getSize(dataContent, "utf-8")
            val startTime: Long = System.currentTimeMillis()
            val result: String? = getClient(client).doPost(url, entity)
            val endTime: Long = System.currentTimeMillis()
            val msg = "result:$result    fileSize:$contentSize / time:${endTime - startTime}ms"
            logger.info(msg)
        } catch (e: Exception) {
            logger.error(e)
            throw e
        }
    }

    /**
     * 保存文件到hdfs
     *
     * @param spiderInstanceId SpiderInstanceID
     * @param fileName         文件名 or 路径/文件名
     * @param content          内容
     */
    @Synchronized
    @Throws(Exception::class)
    fun saveFileSyn(spiderInstanceId: String, fileName: String, content: String) {
        try {
            val entity = WebServiceEntity(Type.HDFS, spiderInstanceId, fileName, content)
            val url: String = newUrl + "savehdfs"
            val contentSize: String = SizeUtil.getSize(content, "utf-8")
            val startTime: Long = System.currentTimeMillis()
            val result: String? = getClient(client).doPost(url, entity)
            val endTime: Long = System.currentTimeMillis()
            val msg = "result:$result   save $spiderInstanceId/$fileName to hdfs success!   fileSize:$contentSize / time:${endTime - startTime}ms"
            logger.info(msg)
        } catch (e: Exception) {
            logger.error(e)
            throw e
        }
    }

    /**
     * 保存stream到hdfs
     *
     * @param spiderInstanceId SpiderInstanceID
     * @param fileName         文件名 or 路径/文件名(需要后缀)
     * @param stream           文件流
     */
    @Synchronized
    @Throws(Exception::class)
    fun saveFileSyn(spiderInstanceId: String, fileName: String, stream: FileInputStream) {
        try {
            val url: String = newUrl + "savehdfs"
            val contentSize: String = SizeUtil.getSize(stream)
            val content: String = Base64Util.file2base64(stream)
            val entity = WebServiceEntity(Type.HDFS, spiderInstanceId, fileName, content, "true")
            val startTime: Long = System.currentTimeMillis()
            val result: String? = getClient(client).doPost(url, entity)
            val endTime: Long = System.currentTimeMillis()
            val msg = "result:$result  save $spiderInstanceId/$fileName to hdfs success!   fileSize:$contentSize / time:${endTime - startTime}ms"
            logger.info(msg)
        } catch (e: Exception) {
            logger.error(e)
            throw e
        } finally {
            stream.close()
        }
    }
    //==================================================================================//

}