package com.hzf.client.util

import net.sf.json.JSONObject

internal object JsonUtil {

    fun str2json(str: String): JSONObject {
        return JSONObject.fromObject(str)

    }

}