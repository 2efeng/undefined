package com.hzf.client.util

import sun.misc.BASE64Decoder
import sun.misc.BASE64Encoder
import java.io.InputStream

internal object Base64Util {

    /**
     * 将文件编码成base64字符串
     */
    @Throws(Exception::class)
    fun file2base64(inputStream: InputStream): String {
        val data = ByteArray(inputStream.available())
        inputStream.read(data)
        val encoder = BASE64Encoder()
        return encoder.encode(data)
    }

    /**
     * 将Base64位编码的文件进行解码成byte[]
     */
    fun decodeBase64ToFile(base64: String): ByteArray {
        val decoder = BASE64Decoder()
        return decoder.decodeBuffer(base64)
    }

}