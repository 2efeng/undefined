package com.hzf.client.constant

enum class DataType {
    /**
     * html格式
     */
    HTML,

    /**
     * json格式
     */
    JSON,

    /**
     * 图片格式
     */
    BITMAP,

    /**
     * 数据流格式
     */
    STREAM
}