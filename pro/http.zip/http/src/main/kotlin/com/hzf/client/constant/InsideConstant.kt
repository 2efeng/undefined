package com.hzf.client.constant

internal enum class Type {
    HBase, HDFS
}

internal interface HBaseParamType {
    companion object {
        val SpiderInstanceId = "SSID"
        val Date = "date"
        val Content = "content"
        val DataType = "dType"
    }
}

internal interface HDFSParamType {
    companion object {
        val SpiderInstanceId = "SSID"
        val FileName = "fileName"
        val Content = "content"
        val IsMutiMediaFile = "isMutiMediaFile"
    }
}

internal interface ResultKey {
    companion object {
        val Result = "isSuccess"
        val ExceptionMsg = "exceptionMsg"
        val Data = "fileNames"
    }
}