package com.hzf.client.manage

import com.hzf.client.constant.*
import java.text.SimpleDateFormat

class WebServiceEntity private constructor() {

    internal constructor(type: Type, param1: Any, param2: Any, param3: Any) : this(type, param1, param2, param3, null)

    internal constructor(type: Type, param1: Any, param2: Any, param3: Any, param4: Any?) : this() {
        when (type) {
            Type.HBase -> {
                param.put(HBaseParamType.SpiderInstanceId, param1)
                val df = SimpleDateFormat("Z yyyy-MM-dd HH:MM:ss:SSS")
                val dateStr: String = df.format(param2)
                param.put(HBaseParamType.Date, dateStr)
                param.put(HBaseParamType.Content, param3)
                if (param4 != null) {
                    param.put(HBaseParamType.DataType, param4)
                }
            }
            Type.HDFS -> {
                param.put(HDFSParamType.SpiderInstanceId, param1)
                param.put(HDFSParamType.FileName, param2)
                param.put(HDFSParamType.Content, param3)
                if (param4 != null) {
                    param.put(HDFSParamType.IsMutiMediaFile, param4)
                }
            }
        }
    }

    private var param = HashMap<Any, Any>()

    fun getParam(): Map<Any, Any> {
        return this.param
    }

    fun getValue(key: Any): Any {
        return this.param.getValue(key)
    }
}