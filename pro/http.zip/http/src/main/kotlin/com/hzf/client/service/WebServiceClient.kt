package com.hzf.client.service

import com.hzf.client.manage.WebServiceEntity

interface WebServiceClient {
    /**
     * Get请求
     *
     * @param url url
     * @return JsonString
     */
    @Throws(Exception::class)
    fun doGet(url: String): String?

    /**
     * Post请求
     *
     * @param url    url
     * @param entity 参数
     * @return JsonString
     */
    @Throws(Exception::class)
    fun doPost(url: String, entity: WebServiceEntity): String?
}