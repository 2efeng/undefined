package com.hzf.client.manage

import org.apache.log4j.Logger
import java.util.*

internal class MsgManage private constructor() {

    companion object {

        private val logger = Logger.getLogger(MsgManage::class.java)
        private var HBaseMsg = LinkedList<WebServiceEntity>()
        private var HDFSMsg = LinkedList<WebServiceEntity>()

        fun putHBaseMsg(entity: WebServiceEntity) {
            synchronized(HBaseMsg) {
                HBaseMsg.add(entity)
                (HBaseMsg as java.lang.Object).notify()
            }
        }

        fun putHDFSMsg(entity: WebServiceEntity) {
            synchronized(HDFSMsg) {
                HDFSMsg.add(entity)

            }
        }


    }


}