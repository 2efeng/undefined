package com.hzf.client.constant

/**
 * 获取url的方式
 */

internal interface SType {
    companion object {
        /**
         * spider
         */
        val Spider = "spider"
    }

}